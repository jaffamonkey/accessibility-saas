# Practical Accessibility SVG logo files

- `logo-light.svg` — deep-navy primary shape for light backgrounds.
- `logo-dark.svg` — white primary shape for dark backgrounds.
- `logo-adaptive.svg` — primary shape uses `currentColor`, so CSS can control it.

Suggested Hugo paths:

```text
static/images/logo-light.svg
static/images/logo-dark.svg
```

Example:

```html
<img src="/images/logo-light.svg" alt="Practical Accessibility">
```
